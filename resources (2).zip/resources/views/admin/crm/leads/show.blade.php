<x-admin-layout
    :title="__('Lead 360').' · '.$lead->lead_name"
    :breadcrumbs="[['label' => __('Leads'), 'url' => route('admin.crm.leads.index')], ['label' => $lead->lead_name]]"
>
    <div
        class="crm-360"
        x-data="{
            tab: new URLSearchParams(window.location.search).get('tab') || 'overview',
            setTab(id) {
                this.tab = id;
                const url = new URL(window.location.href);
                url.searchParams.set('tab', id);
                window.history.replaceState({}, '', url);
            },
        }"
    >
        @include('admin.crm.leads.360.header')
        @include('admin.crm.leads.360.kpi-strip')

        <nav class="crm-360__tabs" aria-label="{{ __('Lead workspace tabs') }}">
            @foreach ([
                'overview' => __('Overview'),
                'activities' => __('Activities'),
                'follow-ups' => __('Follow Ups'),
                'quotations' => __('Quotations'),
                'artwork' => __('Artwork'),
                'timeline' => __('Timeline'),
                'conversion' => __('Conversion History'),
            ] as $id => $label)
                <button
                    type="button"
                    class="crm-360__tab"
                    :class="tab === @js($id) && 'crm-360__tab--active'"
                    @click="setTab(@js($id))"
                    :aria-selected="tab === @js($id)"
                >
                    {{ $label }}
                </button>
            @endforeach
        </nav>

        <div class="crm-360__panels">
            <div x-show="tab === 'overview'" class="crm-360__panel">
                @include('admin.crm.leads.360.tab-overview')
            </div>
            <div x-show="tab === 'activities'" x-cloak class="crm-360__panel">
                @include('admin.crm.leads.360.tab-activities')
            </div>
            <div x-show="tab === 'follow-ups'" x-cloak class="crm-360__panel">
                @include('admin.crm.leads.360.tab-follow-ups')
            </div>
            <div x-show="tab === 'quotations'" x-cloak class="crm-360__panel">
                @include('admin.crm.leads.360.tab-quotations')
            </div>
            <div x-show="tab === 'artwork'" x-cloak class="crm-360__panel">
                @include('admin.crm.leads.360.tab-artwork')
            </div>
            <div x-show="tab === 'timeline'" x-cloak class="crm-360__panel">
                @include('admin.crm.leads.360.tab-timeline')
            </div>
            <div x-show="tab === 'conversion'" x-cloak class="crm-360__panel">
                @include('admin.crm.leads.360.tab-conversion')
            </div>
        </div>
    </div>
</x-admin-layout>
