@props(['filters', 'branches', 'customers', 'salespersons'])

@php
    use App\Enums\QuotationStatus;
@endphp

<x-admin.card class="mb-6">
    <form method="GET" action="{{ route('commercial.reports.quotations.index') }}" data-turbo-frame="erp-main" class="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        <input type="hidden" name="tab" value="{{ $filters['tab'] ?? 'summary' }}">

        <div>
            <label class="text-[11px] text-slate-500" for="from_date">{{ __('From') }}</label>
            <input type="date" id="from_date" name="from_date" value="{{ $filters['from_date'] }}" class="erp-input mt-1 w-full">
        </div>
        <div>
            <label class="text-[11px] text-slate-500" for="to_date">{{ __('To') }}</label>
            <input type="date" id="to_date" name="to_date" value="{{ $filters['to_date'] }}" class="erp-input mt-1 w-full">
        </div>
        <x-admin.consolidated-branch-select
            :branches="$branches"
            :selected="$filters['branch_id'] ?? null"
            select-class="erp-input mt-1 w-full"
        />
        <div>
            <label class="text-[11px] text-slate-500" for="customer_id">{{ __('Customer') }}</label>
            <select id="customer_id" name="customer_id" class="erp-input mt-1 w-full">
                <option value="">{{ __('All customers') }}</option>
                @foreach ($customers as $customer)
                    <option value="{{ $customer->id }}" @selected(($filters['customer_id'] ?? null) == $customer->id)>{{ $customer->company_name }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="text-[11px] text-slate-500" for="salesperson_id">{{ __('Salesperson') }}</label>
            <select id="salesperson_id" name="salesperson_id" class="erp-input mt-1 w-full">
                <option value="">{{ __('All salespersons') }}</option>
                @foreach ($salespersons as $salesperson)
                    <option value="{{ $salesperson->id }}" @selected(($filters['salesperson_id'] ?? null) == $salesperson->id)>{{ $salesperson->name }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="text-[11px] text-slate-500" for="status">{{ __('Status') }}</label>
            <select id="status" name="status" class="erp-input mt-1 w-full">
                <option value="">{{ __('All statuses') }}</option>
                @foreach (QuotationStatus::cases() as $status)
                    <option value="{{ $status->value }}" @selected(($filters['status'] ?? '') === $status->value)>{{ ucfirst(str_replace('_', ' ', $status->value)) }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="text-[11px] text-slate-500" for="expiry_status">{{ __('Expiry Status') }}</label>
            <select id="expiry_status" name="expiry_status" class="erp-input mt-1 w-full">
                <option value="">{{ __('All') }}</option>
                <option value="valid" @selected(($filters['expiry_status'] ?? '') === 'valid')>{{ __('Valid') }}</option>
                <option value="expiring_soon" @selected(($filters['expiry_status'] ?? '') === 'expiring_soon')>{{ __('Expiring Soon') }}</option>
                <option value="expired" @selected(($filters['expiry_status'] ?? '') === 'expired')>{{ __('Expired') }}</option>
            </select>
        </div>
        <div class="md:col-span-2">
            <label class="text-[11px] text-slate-500" for="search">{{ __('Search') }}</label>
            <input
                type="search"
                id="search"
                name="search"
                value="{{ $filters['search'] ?? '' }}"
                placeholder="{{ __('Quote number or customer name…') }}"
                class="erp-input mt-1 w-full"
            >
        </div>
        <div class="flex items-end">
            <button type="submit" class="erp-btn-primary w-full sm:w-auto">{{ __('Apply filters') }}</button>
        </div>
    </form>
</x-admin.card>
