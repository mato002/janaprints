<?php

return [

    'admin_email' => env('JANAPRINTS_ADMIN_EMAIL', env('MAIL_FROM_ADDRESS')),

    'rate_limit' => [
        'max_attempts' => (int) env('PUBLIC_LEADS_RATE_LIMIT', 5),
        'decay_minutes' => (int) env('PUBLIC_LEADS_RATE_DECAY', 15),
    ],

    'crm' => [
        'auto_create_lead' => filter_var(env('PUBLIC_QUOTE_AUTO_CREATE_LEAD', true), FILTER_VALIDATE_BOOL),
        'auto_draft_quotation' => filter_var(env('PUBLIC_QUOTE_AUTO_DRAFT_QUOTATION', false), FILTER_VALIDATE_BOOL),
        'default_company_code' => env('PUBLIC_QUOTE_COMPANY_CODE', 'JANA'),
        'default_branch_code' => env('PUBLIC_QUOTE_BRANCH_CODE', 'HQ'),
        'default_assignee_role' => env('PUBLIC_QUOTE_ASSIGNEE_ROLE', 'Sales'),
    ],

    'artwork' => [
        'disk' => 'public',
        'directory' => 'quote-artwork',
        'max_size_kb' => 25600,
        'allowed_extensions' => ['pdf', 'ai', 'eps', 'psd', 'jpg', 'jpeg', 'png', 'svg'],
        'allowed_mimes' => [
            'application/pdf',
            'application/postscript',
            'application/illustrator',
            'image/vnd.adobe.photoshop',
            'image/jpeg',
            'image/png',
            'image/svg+xml',
        ],
    ],

];
