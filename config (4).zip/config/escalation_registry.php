<?php

return [

    'workflows' => [
        'purchase_request' => [
            'label' => 'Purchase Request',
            'module' => 'procurement',
            'approval_rule_type' => 'purchase_request_approval',
            'document_type' => 'purchase_request',
        ],
        'purchase_order' => [
            'label' => 'Purchase Order',
            'module' => 'procurement',
            'approval_rule_type' => 'procurement_approval',
            'document_type' => 'purchase_order',
        ],
        'rfq' => [
            'label' => 'RFQ',
            'module' => 'procurement',
            'approval_rule_type' => 'rfq_approval',
            'document_type' => 'rfq',
        ],
        'goods_receipt' => [
            'label' => 'Goods Receipt',
            'module' => 'procurement',
            'approval_rule_type' => 'goods_receipt_approval',
            'document_type' => 'goods_receipt',
        ],
        'vendor_invoice' => [
            'label' => 'Vendor Invoice',
            'module' => 'procurement',
            'approval_rule_type' => 'vendor_invoice_approval',
            'document_type' => 'vendor_invoice',
        ],
        'inventory_adjustment' => [
            'label' => 'Inventory Adjustment',
            'module' => 'inventory',
            'approval_rule_type' => 'stock_adjustment_approval',
            'document_type' => 'stock_adjustment',
        ],
        'quotation' => [
            'label' => 'Quotation',
            'module' => 'sales',
            'approval_rule_type' => 'quotation_approval',
            'document_type' => 'quotation',
        ],
        'payment' => [
            'label' => 'Payment',
            'module' => 'finance',
            'approval_rule_type' => 'payment_approval',
            'document_type' => 'payment',
        ],
        'asset_capitalization' => [
            'label' => 'Asset Capitalization',
            'module' => 'assets',
            'approval_rule_type' => 'asset_capitalization_approval',
            'document_type' => 'asset_capitalization',
        ],
    ],

    'waiting_period_presets' => [
        4 => '4 Hours',
        8 => '8 Hours',
        24 => '24 Hours',
        48 => '48 Hours',
        72 => '72 Hours',
        168 => '1 Week',
    ],

];
