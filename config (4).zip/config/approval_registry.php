<?php

return [

    'rule_types' => [

        'quotation_approval' => [
            'label' => 'Quotation Approval',
            'description' => 'Require approval when quotation totals exceed configured amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'quotations.approve',
            'example_tiers' => [50000, 100000, 500000],
        ],

        'discount_approval' => [
            'label' => 'Discount Approval',
            'description' => 'Require approval when discounts exceed configured percentage thresholds.',
            'metric' => 'percent',
            'default_permission' => 'quotations.approve',
            'example_tiers' => [5, 10, 20],
        ],

        'stock_adjustment_approval' => [
            'label' => 'Inventory Adjustment Approval',
            'description' => 'Require approval for stock adjustments above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'inventory.adjust',
            'example_tiers' => [1000, 5000, 10000],
        ],

        'purchase_request_approval' => [
            'label' => 'Purchase Request Approval',
            'description' => 'Require approval for purchase requests above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'procurement.requests.approve',
            'example_tiers' => [10000, 25000, 50000],
        ],

        'procurement_approval' => [
            'label' => 'Purchase Approval',
            'description' => 'Require approval for purchase orders above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'procurement.orders.approve',
            'example_tiers' => [50000, 100000, 250000],
        ],

        'rfq_approval' => [
            'label' => 'RFQ Approval',
            'description' => 'Require approval before issuing RFQs above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'procurement.rfq.create',
            'example_tiers' => [25000, 50000, 100000],
        ],

        'goods_receipt_approval' => [
            'label' => 'Goods Receipt Approval',
            'description' => 'Require approval before posting goods receipts above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'procurement.orders.receive',
            'example_tiers' => [25000, 50000, 100000],
        ],

        'vendor_invoice_approval' => [
            'label' => 'Vendor Invoice Approval',
            'description' => 'Require approval for supplier bills above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'procurement.orders.approve',
            'example_tiers' => [25000, 50000, 100000],
        ],

        'payment_approval' => [
            'label' => 'Payment Approval',
            'description' => 'Require approval for payments above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'procurement.orders.approve',
            'example_tiers' => [100000, 250000, 500000],
        ],

        'asset_capitalization_approval' => [
            'label' => 'Asset Capitalization Approval',
            'description' => 'Require approval for asset capitalization above amount thresholds.',
            'metric' => 'amount',
            'default_permission' => 'assets.acquisition.post',
            'example_tiers' => [100000, 250000, 500000],
        ],

    ],

];
