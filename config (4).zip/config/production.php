<?php

/**
 * Production module defaults (no schedule tables — planning heuristics only).
 */
return [

    /**
     * Maps work center codes to production stage codes (planning visibility only).
     *
     * @var array<string, string>
     */
    'work_center_stage_codes' => [
        'DESIGN' => 'PENDING',
        'PREPRESS' => 'PREPRESS',
        'DIGITAL' => 'PRINTING',
        'OFFSET' => 'PRINTING',
        'LARGE_FORMAT' => 'PRINTING',
        'FINISHING' => 'FINISHING',
        'PACKAGING' => 'DISPATCH',
    ],

    /**
     * Maps job production types to preferred work center codes (first match with capacity wins).
     *
     * @var array<string, string|list<string>>
     */
    'production_type_work_center_codes' => [
        'digital' => 'DIGITAL',
        'offset' => 'OFFSET',
        'large_format' => 'LARGE_FORMAT',
        'finishing' => 'FINISHING',
        'packaging' => 'PACKAGING',
        'mixed' => ['DESIGN', 'PREPRESS', 'DIGITAL'],
    ],

    'scheduling' => [
        /** Max concurrent assigned jobs per work center before overbooked. */
        'default_work_center_capacity' => (int) env('PRODUCTION_WORK_CENTER_CAPACITY', 5),
        'planning_window_days' => 14,
        /** Default span when auto-scheduling a new job card. */
        'default_job_duration_days' => 3,
    ],

];
