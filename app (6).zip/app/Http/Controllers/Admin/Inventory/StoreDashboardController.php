<?php

namespace App\Http\Controllers\Admin\Inventory;

use App\Enums\InventoryDocumentStatus;
use App\Enums\ReorderAlertStatus;
use App\Enums\StockIssueDestination;
use App\Http\Controllers\Controller;
use App\Models\Inventory\InventoryItem;
use App\Models\Inventory\InventoryMovement;
use App\Models\Inventory\InventoryReorderAlert;
use App\Models\Inventory\StockIssue;
use App\Models\Inventory\Warehouse;
use App\Support\Inventory\WarehouseReorderIntelligenceService;
use App\Support\InventoryStockService;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class StoreDashboardController extends Controller
{
    public function __invoke(WarehouseReorderIntelligenceService $intelligence): View
    {
        $this->authorize('viewAny', Warehouse::class);

        $companyId = (int) (tenant()->companyId() ?? $warehouses->first()?->company_id);
        $branchId = (int) (tenant()->branchId() ?? $warehouses->first()?->branch_id);

        $warehouses = Warehouse::query()
            ->forTenant()
            ->withCount('managers')
            ->orderBy('name')
            ->get();

        $balances = InventoryMovement::query()
            ->forTenant()
            ->select('warehouse_id', DB::raw('SUM(quantity) as balance'), DB::raw('SUM(quantity * unit_cost) as stock_value'))
            ->groupBy('warehouse_id')
            ->get()
            ->keyBy('warehouse_id');

        $openAlerts = InventoryReorderAlert::query()
            ->forTenant()
            ->whereIn('status', [ReorderAlertStatus::Open, ReorderAlertStatus::Acknowledged]);

        $stats = [
            'stores' => $warehouses->count(),
            'active_stores' => $warehouses->where('is_active', true)->count(),
            'store_managers' => $warehouses->sum('managers_count'),
            'pending_transfers' => StockIssue::query()
                ->forTenant()
                ->where('destination', StockIssueDestination::Transfer)
                ->where('status', InventoryDocumentStatus::Draft)
                ->count(),
            'reorder_alerts' => (clone $openAlerts)->count(),
            'critical_shortages' => (clone $openAlerts)->where('current_quantity', '<=', 0)->count(),
            'transfer_recommendations' => (clone $openAlerts)->where('replenishment_action', 'transfer')->count(),
        ];

        $lowStockItems = InventoryItem::query()
            ->forTenant()
            ->where('is_active', true)
            ->orderBy('item_name')
            ->get()
            ->filter(function (InventoryItem $item) use ($warehouses) {
                foreach ($warehouses as $warehouse) {
                    $config = app(WarehouseReorderIntelligenceService::class)->resolveConfig($item, $warehouse);
                    $balance = InventoryStockService::balance($item->id, $warehouse->id);
                    if ($config['min_level'] > 0 && $balance <= $config['min_level']) {
                        return true;
                    }
                }

                return false;
            })
            ->take(8);

        return view('admin.inventory.store.dashboard', [
            'warehouses' => $warehouses,
            'balances' => $balances,
            'stats' => $stats,
            'lowStockItems' => $lowStockItems,
            'criticalShortages' => $intelligence->criticalShortages($companyId, $branchId),
            'warehouseHealth' => $intelligence->warehouseStockHealth($companyId, $branchId),
            'transferRecommendations' => $intelligence->transferRecommendations($companyId, $branchId),
        ]);
    }
}
