<?php

namespace App\Enums;

enum SalesOrderStatus: string
{
    case Draft = 'draft';
    case Confirmed = 'confirmed';
    case ReadyForProduction = 'ready_for_production';
    case Queued = 'queued';
    case InProduction = 'in_production';
    case QualityCheck = 'quality_check';
    case ProductionComplete = 'production_complete';
    case ReadyForDispatch = 'ready_for_dispatch';
    /** @deprecated Legacy manual-complete status; prefer ProductionComplete / ReadyForDispatch */
    case Completed = 'completed';
    case Delivered = 'delivered';
    case Closed = 'closed';
    case Cancelled = 'cancelled';
    case OnHold = 'on_hold';

    /**
     * @return list<self>
     */
    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Draft => [self::Confirmed, self::Cancelled, self::OnHold],
            self::Confirmed => [self::ReadyForProduction, self::Cancelled, self::OnHold],
            self::ReadyForProduction => [self::Queued, self::InProduction, self::Cancelled, self::OnHold],
            self::Queued => [self::InProduction, self::Cancelled, self::OnHold],
            self::InProduction => [self::QualityCheck, self::ProductionComplete, self::Cancelled, self::OnHold],
            self::QualityCheck => [self::InProduction, self::ProductionComplete, self::Cancelled, self::OnHold],
            self::ProductionComplete => [self::ReadyForDispatch, self::OnHold],
            self::ReadyForDispatch => [self::Delivered, self::OnHold],
            self::Completed => [self::Delivered, self::ReadyForDispatch, self::OnHold],
            self::Delivered => [self::Closed],
            self::OnHold => [
                self::Confirmed,
                self::ReadyForProduction,
                self::Queued,
                self::InProduction,
                self::QualityCheck,
                self::ProductionComplete,
                self::ReadyForDispatch,
            ],
            self::Closed, self::Cancelled => [],
        };
    }

    public function canTransitionTo(self $status): bool
    {
        return in_array($status, $this->allowedTransitions(), true);
    }

    public function isEditable(): bool
    {
        return $this === self::Draft;
    }

    /**
     * Statuses that indicate production work is finished or downstream.
     *
     * @return list<string>
     */
    public static function productionFinishedValues(): array
    {
        return [
            self::ProductionComplete->value,
            self::ReadyForDispatch->value,
            self::Completed->value,
            self::Delivered->value,
            self::Closed->value,
        ];
    }
}
