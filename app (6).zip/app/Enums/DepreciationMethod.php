<?php

namespace App\Enums;

enum DepreciationMethod: string
{
    case StraightLine = 'straight_line';
    case ReducingBalance = 'reducing_balance';
    case UnitsOfProduction = 'units_of_production';

    public function label(): string
    {
        return match ($this) {
            self::StraightLine => __('Straight Line'),
            self::ReducingBalance => __('Reducing Balance'),
            self::UnitsOfProduction => __('Units of Production'),
        };
    }

    public function isImplemented(): bool
    {
        return $this === self::StraightLine;
    }

    public function isSelectable(): bool
    {
        return $this->isImplemented();
    }

    /**
     * @return list<self>
     */
    public static function selectableCases(): array
    {
        return array_values(array_filter(
            self::cases(),
            fn (self $method) => $method->isSelectable(),
        ));
    }

    /**
     * @return list<string>
     */
    public static function selectableValues(): array
    {
        return array_map(fn (self $method) => $method->value, self::selectableCases());
    }

    public static function tryFromSelectable(?string $value): ?self
    {
        $method = self::tryFrom((string) $value);

        return ($method !== null && $method->isSelectable()) ? $method : null;
    }

    public static function sanitizeValue(?string $value): string
    {
        return self::tryFromSelectable($value)?->value ?? self::StraightLine->value;
    }
}
