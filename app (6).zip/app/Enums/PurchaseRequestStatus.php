<?php

namespace App\Enums;

enum PurchaseRequestStatus: string
{
    case Draft = 'draft';
    case Submitted = 'submitted';
    case PendingApproval = 'pending_approval';
    case Approved = 'approved';
    case Rejected = 'rejected';
    case ConvertedToPo = 'converted_to_po';
    case Closed = 'closed';

    public function isEditable(): bool
    {
        return $this === self::Draft;
    }

    public function canSubmit(): bool
    {
        return $this === self::Draft;
    }

    public function canApprove(): bool
    {
        return in_array($this, [self::Submitted, self::PendingApproval], true);
    }

    public function canConvert(): bool
    {
        return $this === self::Approved;
    }

    public function label(): string
    {
        return match ($this) {
            self::Draft => __('Draft'),
            self::Submitted => __('Submitted — awaiting approval'),
            self::PendingApproval => __('Pending approval'),
            self::Approved => __('Approved'),
            self::Rejected => __('Rejected'),
            self::ConvertedToPo => __('Converted to purchase order'),
            self::Closed => __('Closed'),
        };
    }

    public function conversionLabel(): string
    {
        return match ($this) {
            self::Draft, self::Submitted, self::PendingApproval, self::Rejected => __('Not ready for conversion'),
            self::Approved => __('Ready for RFQ or direct PO'),
            self::ConvertedToPo => __('Converted to purchase order'),
            self::Closed => __('Closed'),
        };
    }
}
